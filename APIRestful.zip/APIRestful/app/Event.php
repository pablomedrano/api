<?php

namespace App;

use App\Seller;
use App\Category;
use App\TicketsEvent;
use Illuminate\Database\Eloquent\Model;

class Event extends Model
{
    const EVENT_AVAILABLE = 'available';
    const EVENT_NOT_AVAILABLE = 'not available';

    protected $fillable = [
    	'name',
    	'description',
    	'city',
    	'date',
    	'cost',
    	'quantity',
    	'status',
    	'seller_id',

    ];

    public function isAvailable(){
    	return $this->status == Event::EVENT_AVAILABLE;
    }

    public function seller(){
        return $this->belongsTo(Seller::class);
    }

    public function ticketsEvents(){
        return $this->hasMany(TicketsEvent::class);
    }

    public function categories(){
        return $this->belongsToMany(Category::class);
    }
}
