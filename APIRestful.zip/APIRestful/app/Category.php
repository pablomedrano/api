<?php

namespace App;

use App\Event;
use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    protected $fillable = [
    	'name',
    	'description',
    ];

    public function events(){
    	return $this->belongsToMany(Event::class);
    }


}
