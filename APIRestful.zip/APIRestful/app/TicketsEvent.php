<?php

namespace App;

use App\Buyer;
use App\Event;
use Illuminate\Database\Eloquent\Model;

class TicketsEvent extends Model
{
    protected $fillable = [
    	'seat',
    	'date',
    	'cost',
    	'buyer_id',
    	'event_id',
    ];

    public function buyer(){
    	return $this->belongsTo(Buyer::class);
    }

    public function event(){
    	return $this->belongsTo(Event::class);
    }
}
