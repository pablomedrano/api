<?php

namespace App;

use App\TicketsEvent;


class Buyer extends User
{
    public function tickets_events(){
    	return $this->hasMany(TicketsEvent::class);
    }
}
