<?php

namespace App;

use App\Event;


class Seller extends User
{
    public function events(){
    	return $this->hasMany(Event::class);
    }
}
