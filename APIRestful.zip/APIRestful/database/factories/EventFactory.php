<?php

use App\User;
use App\Event;
use Faker\Generator as Faker;

$factory->define(Event::class, function (Faker $faker) {
    return [
        'name' => $faker->word,
        'description' => $faker->paragraph(1),
        'city' => $faker->randomElement(['natal','fortaleza','brasilia']),
        'date' => $faker->randomElement(['2019-08-02','2019-09-01','2019-10-10','2019-11-05','2019-12-23']),
        'cost' => $faker->numberBetween(50, 300),
        'quantity' => $faker->numberBetween(1, 10000),
        'status' => $faker->randomElement([Event::EVENT_AVAILABLE, Event::EVENT_NOT_AVAILABLE]),
        'seller_id' => User::all()->random()->id,
    ];
});
