<?php

use App\User;
use App\Seller;
use App\TicketsEvent;
use Faker\Generator as Faker;

$factory->define(TicketsEvent::class, function (Faker $faker) {
	$vendedor = Seller::has('events')->get()->random();
	$comprador = User::all()->except($vendedor->id)->random();
    return [
        'seat' => $faker->numberBetween(1, 2500),
        'date' => $faker->randomElement(['2019-08-02','2019-09-01','2019-10-10','2019-11-05','2019-12-23']),
        'cost' => $faker->numberBetween(50, 300),
        'buyer_id' => $comprador->id,
        'event_id' => $vendedor->events->random()->id,
    ];
});
