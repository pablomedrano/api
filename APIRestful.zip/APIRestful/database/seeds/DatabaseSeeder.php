<?php

use App\User;
use App\Event;
use App\Category;
use App\TicketsEvent;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
    	//desabilitando chaves foraneas
    	DB::statement('SET FOREIGN_KEY_CHECKS = 0');

        User::truncate();
        Category::truncate();
        Event::truncate();
        TicketsEvent::truncate();
        DB::table('category_event')->truncate();

        $cantidadUsuarios = 100;
        $cantidadCategories = 15;
        $cantidadEvents = 100;
        $cantidadTicketsEvents = 500;

        factory(User::class, $cantidadUsuarios)->create();
        factory(Category::class, $cantidadCategories)->create();
        factory(Event::class, $cantidadTicketsEvents)->create()->each(
			function ($evento) {
				$categorias = Category::all()->random(mt_rand(1, 5))->pluck('id');
				$evento->categories()->attach($categorias);
			}
		);        
        factory(TicketsEvent::class, $cantidadTicketsEvents)->create();


    }
}
